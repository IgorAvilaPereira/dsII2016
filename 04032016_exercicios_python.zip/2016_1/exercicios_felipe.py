# -*- coding: utf-8 -*-
"""
Created on Fri Mar  4 10:13:19 2016

@author: iapereira
"""
import funcoes_felipe 

print "Fibonacci:" + str(funcoes_felipe.fibonacci(6))
print "Fatorial:"+ str(funcoes_felipe.fatorial(5))

# pode chamar as demais funcoes do arquivo funcoes_felipe    
    
    
    
    
    
    
    
    
    
    
    
    
        


















